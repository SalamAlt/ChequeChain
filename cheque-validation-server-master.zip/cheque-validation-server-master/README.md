# Cheque Validation API

## Prerequisites

* Docker
* Docker-Compose

## Getting it to run

Just run `docker-compose up -d` in the root of this repository.

This will setup a Couchbase cluster running at http://localhost:8091 and the Cheque API at http://localhost:8080. The Couchbase cluster will have a bucket with fake data generated according to the OpenAPI spec provided by Dr. Saad.

You can use Postman to test the endpoints.