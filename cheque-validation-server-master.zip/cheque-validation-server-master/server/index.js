require('dotenv').config();
const express = require('express');
const app = express()

const couchbase = require('couchbase');
const cluster = new couchbase.Cluster(process.env.COUCHBASE_CLUSTER);
const N1qlQuery = couchbase.N1qlQuery;
cluster.authenticate(process.env.COUCHBASE_USERNAME, process.env.COUCHBASE_PASSWORD);
const bucketName = process.env.COUCHBASE_BUCKET;
const bucket = cluster.openBucket(bucketName);

let sti = setInterval(() => {
    bucket.get('lorem', (err, res) => {
      if (err.message === 'cannot perform operations on a shutdown bucket' ||
         (err instanceof couchbase.Error && err.code === 16)) {
             console.log("connect error");
         cluster.reconnectAll();
       }
      clearInterval(sti);
   });
 }, 10000);
 
app.get('/accounts', (getAccountsRequest, getAccountsResponse) => {
    
    const getAccountsQuery = 
        N1qlQuery.fromString(`
            SELECT c.* from \`${bucketName}\` c 
            WHERE meta().id LIKE "account_%" 
            AND finInstNum = "${getAccountsRequest.query.finInstNum}" 
            AND tranNum = "${getAccountsRequest.query.tranNum}" 
            LIMIT ${parseInt(getAccountsRequest.query.bodyLimit)}
            OFFSET ${(parseInt(getAccountsRequest.query.pageLimit) - 1) * parseInt(getAccountsRequest.query.bodyLimit)}`
    );
    bucket.query(getAccountsQuery, (getAccountsError, getAccountsResult) => {
        if (getAccountsError) {
            getAccountsResponse.sendStatus(500);
        }
        else {
            getAccountsResponse.send(getAccountsResult);
        }
    })
})

app.get('/banks', (getBanksRequest, getBanksResponse) => {
    const getBanksQuery = 
        N1qlQuery.fromString(`
            SELECT c.* from \`${bucketName}\` c 
            WHERE meta().id LIKE "bank_%" 
            LIMIT ${parseInt(getBanksRequest.query.bodyLimit)}
            OFFSET ${(parseInt(getBanksRequest.query.pageLimit) - 1) * parseInt(getBanksRequest.query.bodyLimit)}`
    );
    bucket.query(getBanksQuery, (getBanksError, getBanksResult) => {
        if (getBanksError) {
            getBanksResponse.sendStatus(500);
        }
        else {
            getBanksResponse.send(getBanksResult);
        }
    })
})

app.get('/cheques', (getChequesRequest, getChequesResponse) => {
    const getChequesQuery = 
        N1qlQuery.fromString(`
            SELECT c.* from \`${bucketName}\` c 
            WHERE meta(c).id LIKE "cheque_%" 
            AND chequeId = "${getChequesRequest.query.chequeId}" 
            AND tranNum = "${getChequesRequest.query.tranNum}" 
            AND finInstNum = "${getChequesRequest.query.finInstNum}"
            AND accountId = "${getChequesRequest.query.accountId}"
            AND clientName = "${getChequesRequest.query.clientName}"
            LIMIT ${parseInt(getBanksRequest.query.bodyLimit)}
            OFFSET ${(parseInt(getBanksRequest.query.pageLimit) - 1) * parseInt(getBanksRequest.query.bodyLimit)}`
        );
    bucket.query(getChequesQuery, (getChequesError, getChequesResult) => {
        if (getChequesError) {
            getChequesResponse.sendStatus(500);
        }
        else {
            getChequesResponse.send(getChequesResult);
        }
    })
})

app.post('/cheques', (postChequesRequest, postChequesResponse) => {
    const body = postChequesRequest.body;
    bucket.insert(`cheque_${body.finInstNum}_${body.tranNum}_${body.accountId}`, postChequesRequest.body, (postChequesError) => {
        if (postChequesError) {
            postChequesResponse.sendStatus(500);
        }
        else {
            postChequesResponse.sendStatus(201);
        }
    });
})
app.listen(process.env.PORT, process.env.HOST, () => {
    console.log(`Listening on ${process.env.HOST}:${process.env.PORT}`);
})